### With this plugin you can:

1. Open a GBK File

2. Save file with GBK encoding

3. Change file encoding from utf8 to GBK or GBK to utf8