PHP Obfuscator 0.1
=============================================================================
*This script is in it's very beginning stages. Report any bugs you may find.*

Usage
-----------------------------------------------------------------------------
Refer to 'examples.php' included with the script.
