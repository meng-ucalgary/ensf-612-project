# Hello, there!

Profile: System Engineer - Software Developer (Frontend & Backend) - QA Automated test Developer - Consultant

Skills:

  1. **High Experience**:
    - Ajax
    - Bootstrap
    - ChaiJs
    - CucumberJs
    - ExpressJs
    - Gherkin
    - Git
    - Javascript
    - Jira
    - Json
    - Mocha
    - Php
    - Protractor
    - RestApi
    - Slim
    - SQL
    - XML
  2. **Medium Experience**:
    - AWS (Infraestructure & Code)
    - BrowserStack
    - CypressJs
    - Docker
    - FirebaseJs
    - Heroku
    - Jenkins
    - NativeScript
    - NodeJs
    - NoSQL
    - Ruby On Rails
  3. **Low Experience**:
    - Android
    - AngularJs
    - Corona
    - CQL
    - Django
    - Kubernetes
    - VisualScript

  
