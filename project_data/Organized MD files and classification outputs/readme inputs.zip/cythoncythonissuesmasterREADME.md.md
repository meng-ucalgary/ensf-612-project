# cython-issues
Periodic snapshots of the non-repository data stored on github (e.g. issues and pull requests).

Update this repository with the script at https://github.com/josegonzalez/python-github-backup
  
    python-github-backup/bin/github-backup -u [username] -p [auth-token] -o [cython-issues repo] -O -i --all cython
