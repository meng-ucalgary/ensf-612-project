[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)
![GitHub repo size](https://img.shields.io/github/repo-size/feytus/neptunbot?style=for-the-badge&logo=appveyor)
[![License](https://img.shields.io/github/license/feytus/neptunbot?style=for-the-badge)](https://github.com/feytus/NeptunBOT/blob/main/LICENSE)
___
[![Invite - me](https://img.shields.io/badge/Invite-me-2295c7?style=for-the-badge&logo=discord&logoColor=white)](discord.com/oauth2/authorize?client_id=811977160067776522&permissions=-214438817&scope=applications.commands%20bot)
[![Docs](https://img.shields.io/badge/WEBSITE-DOCUMENTATION-green?style=for-the-badge)](https://feytus.gitbook.io/neptun-doc/)

Neptun BOT is a **usefull** bot totally made in **python** with the module ``discord_py`` and ``discord_slash``.

# Getting started

Check our [documentation](https://feytus.gitbook.io/neptun-doc/)


