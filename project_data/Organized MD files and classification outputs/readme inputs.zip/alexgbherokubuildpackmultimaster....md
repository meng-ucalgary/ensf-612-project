# Deprecated

This project is deprecated and is no longer being maintained.

Please fork it to your own account and update your `BUILDPACK_URL`

You can also check out Heroku's [built-in buildpack-multi support](https://devcenter.heroku.com/articles/using-multiple-buildpacks-for-an-app).

Please check out my current project [Convox](https://convox.com) for all of your deployment needs!
