<!-- ### Hi there 👋 -->

<!--
**bdotdub/bdotdub** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

![Welcome to](https://web.archive.org/web/20091026214418im_/http://geocities.com/heroes.community/welcome.gif)

<h2>My ~*~Github Page~*~</h2>

![Under Construction](https://web.archive.org/web/20091027035610im_/http://es.geocities.com/melgarbeatles6/barraconstruction.gif)

---

- 💍 Looking to join webrings

---

|Github Webring|
|---|
|![Github Programming Webring](https://user-images.githubusercontent.com/5719/87251984-b3fd6a00-c43d-11ea-96a7-b597971ba3e4.png)|
|[[<< Skip Prev]]() \| [[< Prev]]() \| [[Next >]]() \| [[Skip Next >>]]() \| [[Random]]() \| [[List Sites]]()|
