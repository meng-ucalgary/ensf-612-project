# Components

⚠️ This area is a work-in-progress.

This is the main source for our React components. They can be rendered by the server or the client via [Next.js](https://nextjs.org). The starting point for any component usage is the `pages/` directory, which uses a file-system routing paradigm to match paths to pages that then render these components.

