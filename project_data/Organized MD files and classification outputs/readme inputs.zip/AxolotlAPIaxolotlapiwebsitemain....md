# website link
https://theaxolotlapi.netlify.app/

Dev branch site: https://axolotlapi.github.io/axolotlapi-website/

# axolotlapi-website
The official website source for axolotls
