This is the main BIMserver project. The project provides:
- An EMF based database layer for BerkeleyDB Java Edition
- Database migrations
- API's (SOAP, Protocol Buffers, JSON)
- Mail templates
- Notification management
- Caching
- Plugin Management