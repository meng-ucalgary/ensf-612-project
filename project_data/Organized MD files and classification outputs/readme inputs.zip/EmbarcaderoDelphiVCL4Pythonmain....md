# DelphiVCL4Python
Delphi's VCL library as a Python module for building Windows GUI

Installation:

    pip install delphivcl
   
Supports:
* Win32 & Win64 x86 architecturtes
* Python cp36, cp37, cp38, cp39

For other platforms, check out [DelphiFMX4Python](https://github.com/Embarcadero/DelphiFMX4Python).

Powered by [Embarcadero Delphi](https://www.embarcadero.com/products/delphi) and the [Python4Delphi library](https://github.com/pyscripter/python4delphi).
