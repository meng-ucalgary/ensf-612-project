# Spec Tester Documentation

This is a very big idea built on several sleepless nights for the final Telerik Academy Project.

That is why some features are not yet fully developed or have some unexpected behaviour.
This is what we have so far: 

## Home Page

<a href="http://tinypic.com?ref=33b3h3c" target="_blank"><img src="http://i66.tinypic.com/33b3h3c.jpg" border="0" alt="Image and video hosting by TinyPic"></a>

## Cook Logged in Users in Training

Drag and drop products to create a dish. Timer will be added and proper evaluation. Also feedback for user on number of mistakes and may be access to recipe book when not in training.

dragula.js was used to facilitate drag and drop and some very dodgy javascript ajax requests combined with manual json deserialization.

<a href="http://tinypic.com?ref=2ldvgo2" target="_blank"><img src="http://i63.tinypic.com/2ldvgo2.jpg" border="0" alt="Image and video hosting by TinyPic"></a>

## Admin Training Management

<a href="http://tinypic.com?ref=2mfhn55" target="_blank"><img src="http://i63.tinypic.com/2mfhn55.jpg" border="0" alt="Image and video hosting by TinyPic"></a>


## Admin Products page - to Manage Products, create new etc.

<a href="http://tinypic.com?ref=126e3yb" target="_blank"><img src="http://i68.tinypic.com/126e3yb.jpg" border="0" alt="Image and video hosting by TinyPic"></a>

## Admin Manage Area with Statistics 

More statistics coming soon with user roles, location, performance, team statistics, time statistics, etc.

<a href="http://tinypic.com?ref=huoew5" target="_blank"><img src="http://i64.tinypic.com/huoew5.jpg" border="0" alt="Image and video hosting by TinyPic"></a>

## Cook book
Featuring a cook book with recipes with the help of booklet.js that you can flip the pages of. Menu navigation and layout will be changed to accomodate for many more recipe's.

<a href="http://tinypic.com?ref=2uhmm14" target="_blank"><img src="http://i63.tinypic.com/2uhmm14.jpg" border="0" alt="Image and video hosting by TinyPic"></a>

## Error Handling

for now there is only 404 and it handles both 500 and 404. More coming soon

<a href="http://tinypic.com?ref=k2fj8z" target="_blank"><img src="http://i65.tinypic.com/k2fj8z.jpg" border="0" alt="Image and video hosting by TinyPic"></a>

## User statistics 

Comining soon
